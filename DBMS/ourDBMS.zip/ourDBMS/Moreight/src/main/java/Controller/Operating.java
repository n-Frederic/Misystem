package Controller;

import Conditions.Condition;
import Conditions.ConditionNode;
import Conditions.ConditionParser;
import Storage.Page.Tuple;
import Storage.Value.Value;
import Table.*;

import Database.DatabaseManager;
import Table.TableManager;
import UI.UI.CommandHandler;
import User.UserManager;
import Parser.commandParser;
import UI.UI;

import java.io.IOException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import Storage.Value.NullValue;
import Table.Table;
import Util.Func.*;
import Util.Filter.*;
import javax.swing.*;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

public class Operating { // implements CommandHandler
    private static final Pattern PATTERN_INSERT = Pattern.compile("(?i)insert\\s+into\\s+(\\w+)\\s*\\(([^\\)]+)\\)\\s*values\\s*\\(([^\\)]+)\\);?");

    private static final Pattern PATTERN_CREATE_TABLE = Pattern.compile(
            "(?i)create\\s+table\\s+(\\w+)\\s*\\(([^)]*)\\);"
    );
    // 说明：(?i)表示不区分大小写；(?:column\s+)? 表示可选的 "column" 关键字及其后的空白字符
    private static final Pattern PATTERN_ALTER_TABLE = Pattern.compile(
            "(?i)alter\\s+table\\s+(\\w+)\\s+" +            // group1: 表名
                    "(add|drop|modify|change|rename)\\s+" +           // group2: 操作类型
                    "(?:column\\s+)?" +                              // 可选的 column 关键字（不捕获）
                    "(\\w+)" +                                      // group3: 列名（或重命名前的旧列名）
                    "(?:\\s+(.*?))?\\s*;"                           // group4: 其余部分，如列定义、数据类型、约束等（可选），以非贪婪方式匹配直到分号
    );


    // SHOW DATABASES;
    private static final Pattern PATTERN_SHOW_DATABASES =
            Pattern.compile("(?i)^\\s*SHOW\\s+DATABASES\\s*;*\\s*$");

    // SHOW TABLES;
    private static final Pattern PATTERN_SHOW_TABLES =
            Pattern.compile("(?i)^\\s*SHOW\\s+TABLES\\s*;?\\s*$");

    private static final Pattern PATTERN_DELETE = Pattern.compile("(?i)delete\\s+from\\s(\\w+)(?:\\s+where\\s([^\\;]+\\s?;))?");
    private static final Pattern PATTERN_UPDATE = Pattern.compile(
            "(?i)^\\s*UPDATE\\s+" +                     // UPDATE 关键字
                    "([\\w\\.]+)\\s+" +                         // group(1): 表名（支持带点的表名，如 schema.table）
                    "SET\\s+" +                                 // SET 关键字
                    "([^=]+?)\\s*=\\s*(.+?)\\s*" +              // group(2): 列名，group(3): 值
                    "(?:\\s+WHERE\\s+(.+?))?" +                 // group(4): 可选的 WHERE 子句
                    "\\s*;?\\s*$",                              // 可选的结尾分号
            Pattern.DOTALL
    );


    private static final Pattern PATTERN_DROP_TABLE = Pattern.compile("(?i)drop\\s+table\\s+(\\w+)\\s*;?");


    private static final Pattern PATTERN_SELECT = Pattern.compile(
            "(?i)^\\s*SELECT\\s+(.+?)\\s+FROM\\s+(\\w+)" +                   // SELECT 和 FROM 子句
                    "(?:\\s+WHERE\\s+(.+?))?" +                                      // 可选的 WHERE 子句
                    "(?:\\s+GROUP\\s+BY\\s+(.+?))?" +                                // 可选的 GROUP BY 子句
                    "(?:\\s+HAVING\\s+(.+?))?" +                                     // 可选的 HAVING 子句
                    "(?:\\s+ORDER\\s+BY\\s+(.+?))?" +                                // 可选的 ORDER BY 子句
                    "(?:\\s+LIMIT\\s+(\\d+))?" +                                     // 可选的 LIMIT 子句
                    "\\s*;?\\s*$",                                                   // 可选的结尾分号
            Pattern.DOTALL
    );
    private static final Pattern PATTERN_DELETE_INDEX = Pattern.compile("(?i)delete\\s+index\\s(\\w+)\\s?;");
    private static final Pattern PATTERN_GRANT_ADMIN = Pattern.compile("(?i)grant\\s+admin\\s+to\\s([^;\\s]+)\\s?;");
    private static final Pattern PATTERN_REVOKE_ADMIN = Pattern.compile("(?i)revoke\\s+admin\\s+from\\s([^;\\s]+)\\s?;");
    private static final Pattern PATTERN_CREATE_DATABASE = Pattern.compile("(?i)create\\s+database\\s+(\\w+)\\s*;");
    private static final Pattern PATTERN_USE_DATABASE = Pattern.compile("(?i)use\\s+(\\w+)\\s*;");
    private static final Pattern PATTERN_DROP_DATABASE = Pattern.compile("(?i)drop\\s+database\\s+(\\w+)\\s*;");
    private static final Pattern PATTERN_DESC =
            Pattern.compile("(?i)^\\s*(DESC|DESCRIBE)\\s+(\\w+)(\\s*;)?\\s*$");


    private static Scanner sc = new Scanner(System.in);
    private boolean login = false;

    private String log;
    public boolean enter_database = false;

    private UI ui; // 定义 UI 对象

    //ui实验
    String cmd1;
    public Schema schema;

    public static String str1=" ";

    public Operating(String cmd1){
        this.cmd1=cmd1;
    }
    public Operating(){

    }
    public void writeLog(String log){

        String line=log+"\n";
        logUtil.log(line);

    }

    public void dbms() throws IOException {

        do {
            System.out.println("欢迎使用 SimpleDBMS");
            System.out.println("1. 登录");
            System.out.println("2. 注册");

            System.out.print("请输入选项：");

            String choice = sc.nextLine();
            //String choice=cmd1;
            if ("1".equals(choice)) {
                login=UserAuthentication.login(sc);
                System.out.println(login);
            } else if ("2".equals(choice)) {
                login=UserAuthentication.register(sc);
                System.out.println(login);
            }
            else {
                System.out.println("无效选项，程序退出。");
                return;
            }

        } while (!login);
        System.out.println("成功登录，欢迎"+UserManager.getCurrentUser().getUserName());
//
//        SwingUtilities.invokeLater(() -> { // 在 Swing 线程中执行 UI 相关操作
//            ui = new UI(this); // 创建 UI 对象并传入自身作为命令处理
//        });
//        if(UserManager.getCurrentUser().hasPermission("admin")){
//            //System.out.println("start permission");
//           // System.out.println(UserAuthentication.quit);
//            while(!UserAuthentication.quit){
//                UserAuthentication.permissionManagement(sc);
//            }
//
//        }





        Scanner sc = new Scanner(System.in);
        String cmd;
        //尝试把这里的命令行输入变为ui里传来的字符串
        while (!"exit".equals(cmd = sc.nextLine()) && enter_database == false) {
            System.out.println("=== 数据库操作 ===");

            log=cmd;
            boolean matched = false;  // 标记是否匹配成功
            Matcher matcherCreateDB = PATTERN_CREATE_DATABASE.matcher(cmd);
            Matcher matcherUserDB = PATTERN_USE_DATABASE.matcher(cmd);
            Matcher matcherDropDB = PATTERN_DROP_DATABASE.matcher(cmd);
            Matcher matcherShowDB=PATTERN_SHOW_DATABASES.matcher(cmd);


            if (matcherCreateDB.find()) {
                writeLog(log);
                matched = true;
                String dbName = matcherCreateDB.group(1);

                if(TypeFilter.databaseExist(dbName)){
                    System.out.println(dbName+" 已经存在!");
                    continue;
                }
                if(UserManager.getCurrentUser().ddlOK()){
                    System.out.println("创建数据库: " + dbName);
                    DatabaseManager.createDataBase(dbName);

                }else{
                    System.out.println("只有管理员可以创建数据库");
                }



                // 这里你可以调用 parseCreateDatabase(cmd) 或执行创建逻辑
                continue;
            } else if (matcherUserDB.find()) {

                writeLog(log);
                matched = true;
                String dbName = matcherUserDB.group(1);
                if(!TypeFilter.databaseExist(dbName)){
                    System.out.println(dbName+" 不存在!");
                    continue;
                }
                //System.out.println("使用数据库: " + dbName);
                boolean dbexist = false;
                dbexist = DatabaseManager.useDatabase(dbName);
                if (dbexist) {
                    enter_database = true;
                    System.out.println("使用数据库: " + dbName);
                    break;
                } else {
                    System.out.println("数据库不存在");
                }
                // 设置 enter_database = true，表示已进入数据库

                continue;
            } else if (matcherDropDB.find()) {

                writeLog(log);
                matched = true;
                String dbName = matcherDropDB.group(1);

                if(!TypeFilter.databaseExist(dbName)){
                    System.out.println(dbName+" not exist!");
                    continue;
                }

                if(UserManager.getCurrentUser().ddlOK()){
                    System.out.println("删除数据库: " + dbName);
                    DatabaseManager.dropDatabase(dbName);

                }else{
                    System.out.println("只有管理员可以删除数据库");
                }
                continue;

//                // 执行删除逻辑
//                continue;
            }else if(matcherShowDB.find()){
                writeLog(log);
                System.out.println("show");

                List databases=DatabaseManager.listDatabases();
                Render.drawDatabaseList(databases);
                str1=str1+"show"+"\n"+Render.stringBuilder;
                matched=true;

            } else if (!matched) {
                System.out.println("无效命令，请重新输入。");

            }



        }
        System.out.println("请输入sql语句");
        while (!"exit".equals(cmd = sc.nextLine())) {


            log=cmd;
            boolean matched = false;  // 标记是否匹配成功
            Matcher matcherCreateTable = PATTERN_CREATE_TABLE.matcher(cmd);
            Matcher matcherDropTable = PATTERN_DROP_TABLE.matcher(cmd);
            Matcher matcherSelectTable = PATTERN_SELECT.matcher(cmd);
            Matcher matcherInsertTable = PATTERN_INSERT.matcher(cmd);
            Matcher matcherAlterTable = PATTERN_ALTER_TABLE.matcher(cmd);
            Matcher matcherDelete = PATTERN_DELETE.matcher(cmd);
            Matcher matcherUpdate = PATTERN_UPDATE.matcher(cmd);
            Matcher matcherShowTB=PATTERN_SHOW_TABLES.matcher(cmd);
            Matcher matcherDESC=PATTERN_DESC.matcher(cmd);



            if (matcherCreateTable.find()) {
                System.out.println("create");
                matched = true;




                // ✅ 取出表名
                String tableName = matcherCreateTable.group(1);
//                if(TypeFilter.tableExist(tableName)){
//                    System.out.println("表已经存在!");
//                    continue;
//                }




                // ✅ 取出字段定义并解析
                String fieldsStr = matcherCreateTable.group(2);
                ArrayList<Field> fieldList = commandParser.parseCreateTable(fieldsStr);
                if(UserManager.getCurrentUser().ddlOK()){
                    System.out.println("建表: " + tableName);
                    create(fieldList,tableName);



                }else{
                    System.out.println("只有管理员可以建表");
                }
                continue;



            } else if (matcherDropTable.find()) {
                System.out.println("drop");
                // matched = true;
                String tableName = matcherDropTable.group(1);  //
                if(!TypeFilter.tableExist(tableName)){
                    System.out.println("Table 不存在!");
                    continue;
                }

                if(UserManager.getCurrentUser().ddlOK()){

                    System.out.println("删除表: " + tableName);
                    TableManager.DropTable(tableName, 2);


                }else{
                    System.out.println("只有管理员可以删除表");
                }

                continue;

            } else if (matcherSelectTable.find()) {
                System.out.println("select");



                //matched = true;
                select(matcherSelectTable);


                continue;
            } else if(matcherShowTB.find()){
                System.out.println("tables:");
                List<String >tables=TableManager.showTables();
                Render.drawTablesList(tables);
                str1=str1+"tables:"+"\n"+Render.stringBuilder;
                continue;


            } else if (matcherInsertTable.find()) {

                if(UserManager.getCurrentUser().dmlOK()){

                    System.out.println("insert");
                    //matched = true;
                    insert(matcherInsertTable);


                }else{
                    System.out.println("只有用户可以插入数据");
                }


                continue;

            } else if (matcherAlterTable.find()) {

                if(UserManager.getCurrentUser().ddlOK()){
                    System.out.println("alter");
                    alter(matcherAlterTable);


                }else{
                    System.out.println("只有管理员可以修改表结构");
                }


                // matched = true;
                continue;


            } else if (matcherDelete.find()) {

                if(UserManager.getCurrentUser().dmlOK()){
                    String tableName = matcherDelete.group(1);
                    String conditionstr = matcherDelete.group(2);
                    ArrayList<Condition> conditions;

                    Table table=new Table(tableName);
                    ConditionParser parser=new ConditionParser(table);
                    parser.tokenizeWhere(matcherSelectTable.group(3));

                }else{
                    System.out.println("只有用户可以删除数据");
                }



            } else if (matcherUpdate.find()) {


                if(UserManager.getCurrentUser().dmlOK()){
                    String tableName;
                    String conditionstr;

                    update(matcherUpdate);

                }else{
                    System.out.println("只有用户可以更新数据");
                }




                matched = true;
                continue;


            }else if(matcherDESC.find()){
                String tableName=matcherDESC.group(2);
                Table table =new Table(tableName);
                //System.out.println(table.getSchema());
                TableManager.desc(table);
                continue;


            }

            if (!matched) {
                System.out.println("错误输入: " + cmd);  // 调试输出，查看具体输入的命令
                continue;
            }

            System.out.println("matched?" + matched);

        }


    }
//
//    @Override
//    public void handleCommand(String cmd) {
//        System.out.println("\n"); // 打印换行符
//        // 根据命令类型执行不同操作
////        Scanner sc = new Scanner(System.in);
////        String cmd;
//        //尝试把这里的命令行输入变为ui里传来的字符串
//
//        while (!"exit".equals(cmd = sc.nextLine()) && enter_database == false) {
//
//            boolean matched = false;  // 标记是否匹配成功
//            Matcher matcherCreateDB = PATTERN_CREATE_DATABASE.matcher(cmd);
//            Matcher matcherUserDB = PATTERN_USE_DATABASE.matcher(cmd);
//            Matcher matcherDropDB = PATTERN_DROP_DATABASE.matcher(cmd);
//            Matcher matcherShowDB=PATTERN_SHOW_DATABASES.matcher(cmd);
//
//
//            if (matcherCreateDB.find()) {
//                matched = true;
//                String dbName = matcherCreateDB.group(1);
//                System.out.println("创建数据库: " + dbName);
//
//                if(TypeFilter.databaseExist(dbName)){
//                    System.out.println(dbName+" already exist!");
//                    continue;
//                }
//                DatabaseManager.createDataBase(dbName);
//                // 这里你可以调用 parseCreateDatabase(cmd) 或执行创建逻辑
//                continue;
//            } else if (matcherUserDB.find()) {
//
//                matched = true;
//                String dbName = matcherUserDB.group(1);
//                if(!TypeFilter.databaseExist(dbName)){
//                    System.out.println(dbName+" not exist!");
//                    continue;
//                }
//                //System.out.println("使用数据库: " + dbName);
//                boolean dbexist = false;
//                dbexist = DatabaseManager.useDatabase(dbName);
//                if (dbexist) {
//                    enter_database = true;
//                    System.out.println("使用数据库: " + dbName);
//                    break;
//                } else {
//                    System.out.println("数据库不存在");
//                }
//                // 设置 enter_database = true，表示已进入数据库
//
//                continue;
//            } else if (matcherDropDB.find()) {
//
//                matched = true;
//                String dbName = matcherDropDB.group(1);
//
//                if(!TypeFilter.databaseExist(dbName)){
//                    System.out.println(dbName+" not exist!");
//                    continue;
//                }
//
//                System.out.println("删除数据库: " + dbName);
//                DatabaseManager.dropDatabase(dbName, UserManager.GetCurrentUser().getLevel());
//                // 执行删除逻辑
//                continue;
//            }else if(matcherShowDB.find()){
//                System.out.println("show");
//
//                List databases=DatabaseManager.listDatabases();
//                Render.drawDatabaseList(databases);
//                matched=true;
//
//            } else if (!matched) {
//                System.out.println("无效命令，请重新输入。");
//                continue;
//            }
//
//
//
//        }
//        System.out.println("请输入sql语句");
//        while (!"exit".equals(cmd = sc.nextLine())) {
//
//
//            boolean matched = false;  // 标记是否匹配成功
//            Matcher matcherCreateTable = PATTERN_CREATE_TABLE.matcher(cmd);
//            Matcher matcherDropTable = PATTERN_DROP_TABLE.matcher(cmd);
//            Matcher matcherSelectTable = PATTERN_SELECT.matcher(cmd);
//            Matcher matcherInsertTable = PATTERN_INSERT.matcher(cmd);
//            Matcher matcherAlterTable = PATTERN_ALTER_TABLE.matcher(cmd);
//            Matcher matcherDelete = PATTERN_DELETE.matcher(cmd);
//            Matcher matcherUpdate = PATTERN_UPDATE.matcher(cmd);
//            Matcher matcherShowTB=PATTERN_SHOW_TABLES.matcher(cmd);
//            Matcher matcherDESC=PATTERN_DESC.matcher(cmd);
//
//
//
//            if (matcherCreateTable.find()) {
//                System.out.println("create");
//                matched = true;
//
//                // ✅ 取出表名
//                String tableName = matcherCreateTable.group(1);
//                if(TypeFilter.tableExist(tableName)){
//                    System.out.println("Table already exist!");
//                    continue;
//                }
//
//
//
//
//                // ✅ 取出字段定义并解析
//                String fieldsStr = matcherCreateTable.group(2);
//                ArrayList<Field> fieldList = commandParser.parseCreateTable(fieldsStr);
//
//
//                Set<String> existingColumnNames = new HashSet<>();
//                for(Field fieldList1 : fieldList) {
//                    String columnName = fieldList1.getName();
//                    if(existingColumnNames.contains(columnName)) {
//                        System.out.println("column exist!");
//                        continue;
//                    }else{
//                        boolean validtype;
//                        validtype=TypeFilter.typeExist(fieldList);
//                        if(!validtype){
//                            System.out.println("type invalid!");
//                            continue;
//                        }else{
//                            if (fieldList == null) {
//
//
//
//                            } else {
//                                System.out.println("创建表: " + tableName);
//                                for (Field f : fieldList) {
//                                    System.out.println("字段: " + f.getName() + ", 类型: " + f.getType());
//                                }
//                                TableManager.CreateTable(tableName, fieldList);
//                            }
//                            continue;
//
//                        }
//                    }
//                }
//
//
//
//
//            } else if (matcherDropTable.find()) {
//                System.out.println("drop");
//                // matched = true;
//                String tableName = matcherDropTable.group(1);  //
//                Table table=TableCache.getTable(tableName);
//                if(!TypeFilter.tableExist(tableName)){
//                    System.out.println("Table 不存在!");
//                    continue;
//                }
//                if (table.isReferencedByOtherTables()) {
//                    System.out.println("无法删除表 " + tableName + ": 被其他表的外键引用");
//                    continue;
//                }
//
//
//                System.out.println("删除表: " + tableName);     //
//                TableManager.DropTable(tableName, 2);
//                continue;
//
//            } else if (matcherSelectTable.find()) {
//                System.out.println("select");
//                //matched = true;
//                select(matcherSelectTable);
//
//
//                continue;
//            } else if(matcherShowTB.find()){
//                System.out.println("tables:");
//                List<String >tables=TableManager.showTables();
//                Render.drawTablesList(tables);
//                continue;
//
//
//            } else if (matcherInsertTable.find()) {
//                System.out.println("insert");
//                //matched = true;
//                try {
//                    insert(matcherInsertTable);
//                } catch (IOException e) {
//                    throw new RuntimeException(e);
//                }
//                continue;
//
//            } else if (matcherAlterTable.find()) {
//
//                System.out.println("alter");
//                alter(matcherAlterTable);
//                // matched = true;
//                continue;
//
//
//            } else if (matcherDelete.find()) {
//                String tableName = matcherDelete.group(1);
//                String conditionstr = matcherDelete.group(2);
//                ArrayList<Condition> conditions;
//
//                Table table=TableCache.getTable(tableName);
//                ConditionParser parser=new ConditionParser(table);
//                parser.tokenizeWhere(matcherSelectTable.group(3));
//                // 在删除前检查是否有其他表的外键引用此记录
//                if (table.isReferencedByOtherTables()) {
//                    System.out.println("存在其他表的外键引用，删除列不成功");
//                    continue;
//                }
//
//
//            } else if (matcherUpdate.find()) {
//                String tableName;
//                String conditionstr;
//
//                update(matcherUpdate);
//
//                matched = true;
//                continue;
//
//
//            }else if(matcherDESC.find()){
//                String tableName=matcherDESC.group(1);
//                TableManager.desc( TableCache.getTable(tableName));
//
//            }
//
//            if (!matched) {
//                System.out.println("错误输入: " + cmd);  // 调试输出，查看具体输入的命令
//                continue;
//            }
//
//            System.out.println("matched?" + matched);
//
//        }
//
//
//    }
//
//


//        private void createDB(Matcher matcherCreateTable) {
//                String tableName = matcherCreate.group(1);
//                String propertys = matcherCreateTable.group(2);
//                Map<String, Field> fieldMap = StringUtil.parseCreateTable(propertys);
//                System.out.println(TableManager.CreateTable(tableName, fieldMap));
//        }

    private void dropDB(Matcher matcherDropTable) {
        String tableName = matcherDropTable.group(1);
//                System.out.println(TableManager.DropTable(tableName));
    }

    private void useDB(Matcher matcherDropTable) {
        String tableName = matcherDropTable.group(1);
//                System.out.println(Table.dropTable(tableName));
    }

    public static boolean checkType(JsonElement value, String expectedType) {
        switch (expectedType.toLowerCase()) {
            case "int":
                return value.isJsonPrimitive() && ((JsonPrimitive) value).isNumber() &&
                        value.getAsJsonPrimitive().getAsString().matches("-?\\d+");
            case "float":
                return value.isJsonPrimitive() && ((JsonPrimitive) value).isNumber();
            case "string":
                return value.isJsonPrimitive() && ((JsonPrimitive) value).isString();
            case "boolean":
                return value.isJsonPrimitive() && ((JsonPrimitive) value).isBoolean();
            default:
                return false;
        }
    }

    /**
     * 检查列是否存在，支持聚合函数中的列
     * @param table 表对象
     * @param columns 要检查的列名列表（可能包含聚合函数）
     * @return 所有列都有效返回true，否则返回false
     */

    private boolean checkColumnsExist(Table table, List<?>  columns) {
        for (Object column : columns) {
            // 检查是否是聚合函数
            String[] aggInfo = commandParser.parseAggregateFunction(column.toString());

            if (aggInfo != null) {
                // 处理聚合函数中的列
                String aggColumn = aggInfo[1]; // 获取聚合参数

                // 特殊处理count(*)
                if (aggColumn.equals("*")) {
                    continue; // count(*) 总是有效
                }

                // 检查聚合参数是否是有效列
                if (!TypeFilter.columnExist(table, aggColumn)) {
                    System.out.println("聚合函数 " + column + " 中的列 '" + aggColumn + "' 不存在!");
                    return false;
                }
            } else {
                // 普通列检查
                if (!TypeFilter.columnExist(table, column.toString())) {
                    System.out.println("列 '" + column + "' 不存在!");
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * 应用 GROUP BY 分组操作
     */
    private ArrayList<Tuple> applyGroupBy(ArrayList<Tuple> data,
                                          ArrayList<String[]> columns,
                                          String groupByStr,
                                          Table table) {
        // 1. 解析 GROUP BY 列
        String[] groupByColumns = groupByStr.split("\\s*,\\s*");

        // 2. 验证 GROUP BY 列是否存在
        for (String col : groupByColumns) {
            if (!TypeFilter.columnExist(table, col)) {
                System.out.println("GROUP BY column '" + col + "' not exist!");
                return data; // 返回原始数据或抛出异常
            }
        }

        // 3. 分组数据
        Map<Tuple, ArrayList<Tuple>> groups = new HashMap<>();
        for (Tuple tuple : data) {
            // 创建分组键（只包含 GROUP BY 列的值）
            Tuple key = createGroupKey(tuple, groupByColumns, table.getSchema());

            // 将元组添加到对应的分组
            groups.computeIfAbsent(key, k -> new ArrayList<>()).add(tuple);
        }

        // 4. 对每个分组应用聚合函数
        ArrayList<Tuple> result = new ArrayList<>();
        for (Map.Entry<Tuple, ArrayList<Tuple>> entry : groups.entrySet()) {
            Tuple groupedTuple = applyAggregates(entry.getKey(), entry.getValue(), columns);
            result.add(groupedTuple);
        }

        return result;
    }

    /**
     * 创建分组键
     */
    private Tuple createGroupKey(Tuple tuple, String[] groupByColumns, Schema schema) {
        // 实现根据 GROUP BY 列创建键的逻辑
        Tuple key=new Tuple();
        // ...
        return key;
    }

    /**
     * 应用聚合函数
     */
    private Tuple applyAggregates(Tuple groupKey, ArrayList<Tuple> groupTuples, ArrayList<String[]> columns) {
        Tuple resultTuple=new Tuple();
        // ...
        return resultTuple;
    }
    private boolean create(ArrayList<Field> fieldList,String tableName)throws IOException {
        Set<String> existingColumnNames = new HashSet<>();
        for (Field fieldList1 : fieldList) {
            String columnName = fieldList1.getName();
            if (existingColumnNames.contains(columnName)) {
                System.out.println("column exist!");
                return false;
            } else {
                boolean validtype;
                validtype = TypeFilter.typeExist(fieldList);
                if (!validtype) {
                    System.out.println("type invalid!");
                    return false;
                } else {

                    if (fieldList1.isForeignKey()) {
                        // 验证引用的表和列是否存在
                        if (!TypeFilter.tableExist(fieldList1.getReferenceTable())) {
                            System.out.println("外键引用的表 " + fieldList1.getReferenceTable() + " 不存在");
                            return false;
                        }
                        if (!TypeFilter.columnExist(new Table(fieldList1.getReferenceTable()),
                                fieldList1.getReferenceColumn())) {
                            System.out.println("外键引用的列 " + fieldList1.getReferenceColumn() + " 不存在");
                            return false;
                        }
                    }

                    if (fieldList == null) {


                    } else {
                        System.out.println("创建表: " + tableName);
                        for (Field f : fieldList) {
                            System.out.println("字段: " + f.getName() + ", 类型: " + f.getType());
                        }
                        TableManager.CreateTable(tableName, fieldList);
                    }
                    continue;

                }

            }

        }
        return true;

    }

    private boolean select(Matcher matcherSelect) throws IOException{
        str1=" ";
        String tableName = matcherSelect.group(2);
        if(!TypeFilter.tableExist(tableName)){
            System.out.println(tableName+" not exist!");

        }else{
            Table table=new Table(tableName);
            ArrayList<String> columns = new ArrayList<>();
            ArrayList<Condition> conditions = new ArrayList<>();

            ArrayList<Tuple> data;


//
            String columnsStr = matcherSelect.group(1);
            if (columnsStr.equals("*")) {
                Schema schema=table.getSchema();
                columns = new ArrayList<>();
                columns=schema.getColumns();
                data=table.selectAll();




            } else {
                columns = commandParser.parseSelectColumn(columnsStr);

                checkColumnsExist(table,columns);
                for(Object column:columns){
                    if(!TypeFilter.columnExist(table,column.toString())){
                        System.out.println("column not exist!");
                        return false;

                    }
                }


            }
            if(!(matcherSelect.group(3)==null)){
                System.out.println("with conditions");
                String conditionStr = matcherSelect.group(3).toLowerCase().trim();
                conditionStr=commandParser.parseBetweenAnd(conditionStr);
                ConditionNode logicTree;
                ConditionParser parser=new ConditionParser(table);
                List<String> tokens = parser.tokenizeWhere(conditionStr);
                logicTree = parser.parseConditionTree(tokens);
                data=logicTree.evaluate();
                System.out.println("条件表达式树结构为：");
                System.out.println(logicTree);



            }else{
                data=table.selectAll();
            }

            // 解析 GROUP BY 子句
//            if (matcherSelect.group(4) != null) {
//                String groupByStr = matcherSelect.group(4).trim();
//                data = applyGroupBy(data, columns, groupByStr, table);
//            }
//
////
            // System.out.println("conditions: " + conditions);


            System.out.println(columns);

            data = table.select(data,columns);
            Render.DrawSelectedTable(data,columns);
            System.out.println("draw");
            str1=str1+"draw:"+"\n"+Render.stringBuilder;


        }
        return true;


    }


    private void alter(Matcher matcherAlter)throws IOException{


        //System.out.println("altering1");
        String tableName;
        String details;
        String column;
        String operation;
        tableName = matcherAlter.group(1);
        System.out.println(tableName);
        if(!TypeFilter.tableExist(tableName)){
            System.out.println(tableName+" not exist!");
            str1=str1+tableName+" not exist!";

        }else{
            column = matcherAlter.group(3);//name
            System.out.println(column);

            operation = matcherAlter.group(2);
            System.out.println(operation);// "add"

            Table table=new Table(tableName);



            if(operation.equals("add")||operation.equals("ADD")){
                //System.out.println("adding");
                details=matcherAlter.group(4);
                //System.out.println("detail");

                Field field=new Field(column,details);

                TableManager.addColumn(field,table);

            }else if (operation.equals("drop") || operation.equals("DROP")) {
                // 检查该列是否被其他表的外键引用
                if (table.isColumnReferenced(column)) {
                    System.out.println("无法删除列 " + column + ": 被其他表的外键引用");
                    str1=str1+tableName+"无法删除列 " + column + ": 被其他表的外键引用";
                    return;
                }
                TableManager.dropColumn(column, table);
            }else if (operation.equals("modify") || operation.equals("MODIFY")) {
                // 检查该列是否是外键或被外键引用
                if (table.isColumnForeignKey(column) || table.isColumnReferenced(column)) {
                    System.out.println("无法修改外键列 " + column + " 的类型");
                    str1=str1+tableName+"无法修改外键列 " + column + " 的类型";
                    return;
                }
                details=matcherAlter.group(4);
                Field field=new Field(column,details);
                TableManager.modifyColumn(table,column,field);
                // ...执行修改...
            }else if(operation.equals("rename")||operation.equals("RENAME")){
                details=matcherAlter.group(4);
                Field field=new Field(column,details);
                TableManager.renameColumn(column,details,table);

            }
            // "age int

//        switch (operation){
//            case "add":
//                ArrayList<String ,String>fields = commandParser.parseCreateTable(fieldString);
//
//        }
            ArrayList<Field> fields = new ArrayList<>();
            //fields = commandParser.parseCreateTable(fieldString);

        }



    }


    private void update(Matcher mathcerUpdate)throws IOException{
        String tableName=mathcerUpdate.group(1);
        String statement=mathcerUpdate.group(2);
        String conditionStr=mathcerUpdate.group(4);
        ArrayList<Tuple> data;
        System.out.println(":"+tableName+":"+statement+":"+conditionStr);
        str1=str1+":"+tableName+":"+statement+":"+conditionStr;
        if (!TypeFilter.tableExist(tableName)) {
            System.out.println(tableName + " not exist!");

            str1=str1+tableName + " not exist!";
        } else {
            conditionStr = commandParser.parseBetweenAnd(conditionStr);
            ConditionNode logicTree;
            Table table = new Table(tableName);
            ConditionParser parser = new ConditionParser(table);
            List<String> tokens = parser.tokenizeWhere(conditionStr);
            logicTree = parser.parseConditionTree(tokens);
            System.out.println(logicTree);
            data = logicTree.evaluate();

//            HashMap<String,String> statements=commandParser.parseUpdateSet(statement);
//            if (table.hasForeignKeyConstraints()) {
//                for (Map.Entry<String, String> entry : statements.entrySet()) {
//                    Field field = schema.getField(entry.getKey());
//                    if (field != null && field.isForeignKey()) {
//                        Table refTable = new Table(tableName);
////                        if (!refTable.containsValue(field.getReferenceColumn(), entry.getValue())) {
////                            System.out.println("违反外键约束: 值 " + entry.getValue() + " 在表 " +
////                                    field.getReferenceTable() + " 的 " +
////                                    field.getReferenceColumn() + " 列中不存在");
////                            return;
////                        }
//                    }
//                }
//            }
            //System.out.println("taaaaa"+table.getSchema().getPrimaryKeyName()+"group2"+mathcerUpdate.group(2));
            String type = table.getSchema().getField(mathcerUpdate.group(2)).getType();

            Class<? extends Value> classtype = commandParser.findClass(type);
            String valueWithoutQuotes = mathcerUpdate.group(3).replaceAll("'", "");

            table.update(data, Value.parse(classtype, valueWithoutQuotes), mathcerUpdate.group(2));
            Render.DrawSelectedTable(data,table.getSchema().getColumns());

            str1=str1+Render.stringBuilder;

        }




    }

    private void insert(Matcher matcherInsert) throws IOException {
        String tableName   = matcherInsert.group(1);
        List<String> columns   = commandParser.parseInsertColumn(matcherInsert.group(2));
        List<Object> rawValues = commandParser.parseInsertValue(matcherInsert.group(3));
        System.out.println(tableName);
        System.out.println(columns);
        System.out.println(rawValues );
        Table table=new Table(tableName);
        Schema schema  = table.getSchema();


        try{
            Tuple t=TypeFilter.createTupleFromInsertValues(schema, columns, rawValues);
            t.showAll();
            if(table.samePK(t.getPrimaryV())){
                table.insert(t);
                System.out.println("插入成功");
                str1=str1+"插入成功";
            }else{
                System.out.println("相同主键");
                str1=str1+"相同主键，插入失败！";
            }



        }catch (Exception e){
            System.out.println("fail to create tuple");
            str1=str1+"fail to create tuple";
        }
//
//        if(!TypeFilter.tableExist(tableName)){
//            System.out.println(tableName+" not exist!");
//
//
//        }else if(true){
        // --- load schema ---


//            // 1. 校验并转换
//            List<Value> castedValues = TypeFilter.validateAndConvertValues(columns, rawValues, schema);
//
//           System.out.println(castedValues.get(1).getType());
//           System.out.println(columns.get(1));
//
//            Tuple keyTuple = buildTuple(columns, castedValues, schema);

//            // 2. 真正调用插入
//            if (table.hasForeignKeyConstraints()) {
//                for (Field field : schema.getFields()) {
//                    if (field.isForeignKey()) {
//                        Value fkValue = castedValues.get(columns.indexOf(field.getName()));
//                        Table refTable = new Table(field.getReferenceTable());
//                        if (!refTable.containsValue(field.getReferenceColumn(), fkValue)) {
//                            System.out.println("违反外键约束: 值 " + fkValue + " 在表 " +
//                                    field.getReferenceTable() + " 的 " +
//                                    field.getReferenceColumn() + " 列中不存在");
//                            return;
//                        }
//                    }
//                }
//            }





//        }

    }
    private Tuple buildTuple(
            List<String> columns,
            List<Value>  values,
            Schema       schema) {

        // 1. 准备列名→下标的映射
        List<Field> fields = schema.getFields();
        Map<String,Integer> colIdx = new HashMap<>();
        for (int i = 0; i < fields.size(); i++) {
            colIdx.put(fields.get(i).getName().toLowerCase(), i);
        }

        // 2. 创建一个和全表列数一样大的 Value 数组，默认填 null（或你定义的 NullValue）
        Value[] arr = new Value[fields.size()];
        for (int i = 0; i < arr.length; i++) {
            arr[i] = new NullValue();  // 假设你已有一个 NullValue 实现
        }

        // 3. 把用户指定列的位置，用实际转换后的值覆盖进去
        for (int i = 0; i < columns.size(); i++) {
            String col = columns.get(i).toLowerCase();
            int idx    = colIdx.get(col);    // 一定存在，否则前面 validate 就会报错
            arr[idx]   = values.get(i);

            System.out.println(values.get(i).getType());
        }

        // 4. 用这个数组构造一个 Tuple 返回
        return new Tuple(arr);
    }

    /**
     * 与ui连接的试用方法
     * @param command
     * @return
     */
    // 处理用户输入的命令
    public String processCommand(String command) {
        boolean matched = false;
        // 匹配 create table 命令
        Matcher matcherCreateTable = PATTERN_CREATE_TABLE.matcher(command);
        if (matcherCreateTable.find()) {
            return handleCreateTable(matcherCreateTable,matched);
        }

        // 如果命令不匹配，返回错误信息
        return "无效命令: " + command;
    }

    // 处理 create table 命令
    private String handleCreateTable(Matcher matcher,boolean matched ) {
//        System.out.println("create");
//        matched = true;
//
//        // ✅ 取出表名
//        String tableName = matcher.group(1);
//        if(TypeFilter.tableExist(tableName)){
//            System.out.println("Table already exist!");
//            return "Table already exist!";
//        }
//        // ✅ 取出字段定义并解析
//        String fieldsStr = matcher.group(2);
//        ArrayList<Field> fieldList = commandParser.parseCreateTable(fieldsStr);
//
//
//        Set<String> existingColumnNames = new HashSet<>();
//        for(Field fieldList1 : fieldList) {
//            String columnName = fieldList1.getName();
//            if(existingColumnNames.contains(columnName)) {
//                System.out.println("column exist!");
//                return "column exist!";
//
//            }else{
//                boolean validtype;
//                validtype=TypeFilter.typeExist(fieldList);
//                if(!validtype){
//                    System.out.println("type invalid!");
//                    return "type invalid!";
//
//                }else{
//                    if (fieldList == null) {
//
//                    } else {
//                        System.out.println("创建表: " + tableName);
//                        for (Field f : fieldList) {
//                            System.out.println("字段: " + f.getName() + ", 类型: " + f.getType());
//                            return "字段: " + f.getName() + ", 类型: " + f.getType();
//                        }
//                        //TableManager.CreateTable(tableName, fieldList);
//                    }
//                }
//            }
//        }
        return "   ";
    }


    public void logAndRegister(String str) throws IOException {
//        str1=" ";
//        if(!"exit".equals(str) && enter_database == false) {
//            System.out.println("=== 数据库操作 ===");
//            str1=str1+"=== 数据库操作 ==="+"\n";
//
//            boolean matched = false;  // 标记是否匹配成功
            str1=" ";
            System.out.println("=== 数据库操作 ===");
            str1 = str1 + "=== 数据库操作 ===" + "\n";
            Matcher matcherCreateDB = PATTERN_CREATE_DATABASE.matcher(str);
            Matcher matcherUserDB = PATTERN_USE_DATABASE.matcher(str);
            Matcher matcherDropDB = PATTERN_DROP_DATABASE.matcher(str);
            Matcher matcherShowDB=PATTERN_SHOW_DATABASES.matcher(str);


            log=str;
            if (matcherCreateDB.find()) {
                writeLog(log);
//                matched = true;
                String dbName = matcherCreateDB.group(1);

                if(TypeFilter.databaseExist(dbName)){
                    System.out.println(dbName+" 已经存在!");
                    str1=str1+dbName+"已经存在!"+"\n";

                } else {
                    if(UserManager.getCurrentUser().ddlOK()){
                        System.out.println("创建数据库: " + dbName);
                        DatabaseManager.createDataBase(dbName);
                        str1=str1+"创建数据库: " + dbName;

                    }else{
                        System.out.println("只有管理员可以创建数据库");
                        str1=str1+"只有管理员可以删除数据库";
                    }
                }

            } else if (matcherUserDB.find()) {
                writeLog(log);
//                matched = true;
                String dbName = matcherUserDB.group(1);
//                if(TypeFilter.databaseExist(dbName)){
//                    enter_database=true;
//                    System.out.println("使用数据库: " + dbName);
//                    str1=str1+"\"使用数据库: \" + dbName";
//                }else {
//                    System.out.println(dbName+" 不存在!");
//                    str1=str1+"\n"+dbName+" 不存在!";
//                }

                boolean dbexist = false;
                dbexist = DatabaseManager.useDatabase(dbName);
                if (dbexist) {
                    enter_database = true;
                    System.out.println("使用数据库: " + dbName);
                    str1=str1+"使用数据库: " + dbName;

                } else {
                    System.out.println("数据库不存在");
                    str1=str1+"数据库不存在";
                }
                // 设置 enter_database = true，表示已进入数据库


            } else if (matcherDropDB.find()) {
                writeLog(log);
//                matched = true;
                String dbName = matcherDropDB.group(1);

                if(!TypeFilter.databaseExist(dbName)){
                    System.out.println(dbName+" not exist!");
                    str1=str1+dbName+" not exist!"+"\n";

                } else {

                    if(UserManager.getCurrentUser().ddlOK()){
                        System.out.println("删除数据库: " + dbName);
                        DatabaseManager.dropDatabase(dbName);
                        str1=str1+"删除数据库: " + dbName;

                    }else{
                        System.out.println("只有管理员可以删除数据库");
                        str1=str1+"只有管理员可以删除数据库";
                    }
                }



//                // 执行删除逻辑
//                continue;
            } else if(matcherShowDB.find()){
                writeLog(log);
                System.out.println("show");


                List databases=DatabaseManager.listDatabases();
                Render.drawDatabaseList(databases);

//                matched=true;
                str1=str1+"show"+"\n"+Render.stringBuilder;

//            } else if (!matched) {
//                System.out.println("无效命令，请重新输入。");
//                str1=str1+"无效命令，请重新输入。";
//            }
            }
    }

    public String isDB(String str)throws IOException{
        str1=" ";
        if(!"exit".equals(str) && enter_database == false) {


            boolean matched = false;  // 标记是否匹配成功
            Matcher matcherCreateDB = PATTERN_CREATE_DATABASE.matcher(str);
            Matcher matcherUserDB = PATTERN_USE_DATABASE.matcher(str);
            Matcher matcherDropDB = PATTERN_DROP_DATABASE.matcher(str);
            Matcher matcherShowDB = PATTERN_SHOW_DATABASES.matcher(str);

            Matcher matcherCreateTable = PATTERN_CREATE_TABLE.matcher(str);
            Matcher matcherDropTable = PATTERN_DROP_TABLE.matcher(str);
            Matcher matcherSelectTable = PATTERN_SELECT.matcher(str);
            Matcher matcherInsertTable = PATTERN_INSERT.matcher(str);
            Matcher matcherAlterTable = PATTERN_ALTER_TABLE.matcher(str);
            Matcher matcherDelete = PATTERN_DELETE.matcher(str);
            Matcher matcherUpdate = PATTERN_UPDATE.matcher(str);
            Matcher matcherShowTB=PATTERN_SHOW_TABLES.matcher(str);
            Matcher matcherDESC=PATTERN_DESC.matcher(str);


            log=str;
            if (matcherCreateDB.find()||matcherUserDB.find()||matcherDropDB.find()||matcherShowDB.find()) {

                writeLog(log);
                Operating operating=new Operating();
                operating.logAndRegister(str);
            } else if (matcherCreateTable.find() || matcherDropTable.find() || matcherSelectTable.find() || matcherInsertTable.find() || matcherAlterTable.find() || matcherDelete.find() || matcherUpdate.find() || matcherShowTB.find() || matcherDESC.find()) {
                Operating operating=new Operating();
                operating.logAndRegister1(str);
            } else {
                str1="无效命令！";
            }

        }
        return str1;
    }

    public void logAndRegister1(String str) throws IOException {
//        str1=" ";
//        //System.out.println("请输入sql语句");
//        if (!"exit".equals(str)) {


//            boolean matched = false;  // 标记是否匹配成功
        Matcher matcherCreateTable = PATTERN_CREATE_TABLE.matcher(str);
        Matcher matcherDropTable = PATTERN_DROP_TABLE.matcher(str);
        Matcher matcherSelectTable = PATTERN_SELECT.matcher(str);
        Matcher matcherInsertTable = PATTERN_INSERT.matcher(str);
        Matcher matcherAlterTable = PATTERN_ALTER_TABLE.matcher(str);
        Matcher matcherDelete = PATTERN_DELETE.matcher(str);
        Matcher matcherUpdate = PATTERN_UPDATE.matcher(str);
        Matcher matcherShowTB = PATTERN_SHOW_TABLES.matcher(str);
        Matcher matcherDESC = PATTERN_DESC.matcher(str);


        log=str;
        if (matcherCreateTable.find()) {
            writeLog(log);
            System.out.println("create");
//                matched = true;
            // ✅ 取出表名
            String tableName = matcherCreateTable.group(1);
            if (TypeFilter.tableExist(tableName)) {
                System.out.println("表已经存在!");
                str1 = str1 + "表已经存在!";

            } else {
                // ✅ 取出字段定义并解析
                String fieldsStr = matcherCreateTable.group(2);
                ArrayList<Field> fieldList = commandParser.parseCreateTable(fieldsStr);
                if (UserManager.getCurrentUser().ddlOK()) {
                    System.out.println("建表: " + tableName);
                    create(fieldList, tableName);
                    str1 = str1 + "建表: " + tableName;

                } else {
                    System.out.println("只有管理员可以建表");
                    str1 = str1 + "只有管理员可以建表";
                }
            }
        } else if (matcherDropTable.find()) {
            writeLog(log);
            System.out.println("drop");
            // matched = true;
            String tableName = matcherDropTable.group(1);  //
            if (!TypeFilter.tableExist(tableName)) {
                System.out.println("Table 不存在!");
                str1 = str1 + "Table 不存在!";
            }else {

                if (UserManager.getCurrentUser().ddlOK()) {

                    System.out.println("删除表: " + tableName);
                    TableManager.DropTable(tableName, 2);
                    str1 = str1 + "删除表: " + tableName;


                } else {
                    System.out.println("只有管理员可以删除表");
                    str1 = str1 + "只有管理员可以删除表";
                }

            }
        } else if (matcherSelectTable.find()) {
            writeLog(log);
            System.out.println("select");
            //matched = true;
            select(matcherSelectTable);

        } else if (matcherShowTB.find()) {
            writeLog(log);
            System.out.println("tables:");
            List<String> tables = TableManager.showTables();
            Render.drawTablesList(tables);
            str1 = str1 + "tables:" + "\n" + Render.stringBuilder;


        } else if (matcherInsertTable.find()) {
            writeLog(log);

            if (UserManager.getCurrentUser().dmlOK()) {

                System.out.println("insert");
                //matched = true;
                insert(matcherInsertTable);


            } else {
                System.out.println("只有用户可以插入数据");
                str1 = str1 + "只有用户可以插入数据";
            }


        } else if (matcherAlterTable.find()) {
            writeLog(log);

            if (UserManager.getCurrentUser().ddlOK()) {
                System.out.println("alter");
                alter(matcherAlterTable);


            } else {
                System.out.println("只有管理员可以修改表结构");
                str1 = str1 + "只有管理员可以修改表结构";
            }


            // matched = true;


        } else if (matcherDelete.find()) {
            writeLog(log);

            if (UserManager.getCurrentUser().dmlOK()) {
                String tableName = matcherDelete.group(1);
                String conditionstr = matcherDelete.group(2);
                ArrayList<Condition> conditions;

                Table table = new Table(tableName);
                ConditionParser parser = new ConditionParser(table);
                parser.tokenizeWhere(matcherSelectTable.group(3));

            } else {
                System.out.println("只有用户可以删除数据");
                str1 = str1 + "只有用户可以删除数据";

            }


        } else if (matcherUpdate.find()) {
            writeLog(log);


            if (UserManager.getCurrentUser().dmlOK()) {
                String tableName;
                String conditionstr;

                update(matcherUpdate);


            } else {
                System.out.println("只有用户可以更新数据");
                str1 = str1 + "只有用户可以更新数据";
            }


//                matched = true;


        } else if (matcherDESC.find()) {
            writeLog(log);
            String tableName = matcherDESC.group(2);
            Table table = new Table(tableName);
            //System.out.println(table.getSchema());
            TableManager.desc(table);
            str1 = str1 + Render.stringBuilder;


        }

    }
}







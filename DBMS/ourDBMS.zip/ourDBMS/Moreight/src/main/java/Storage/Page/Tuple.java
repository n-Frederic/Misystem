package Storage.Page;
import Storage.Value.*;
import Conditions.Condition;
import Storage.Value.Value;
import Table.Field;
import Table.Schema;
import Conditions.*;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class Tuple {

    protected ArrayList<Value> values;

    protected Value primaryV;

    public Tuple() {}

    public Tuple(Value value) {
        this.values = new ArrayList<Value>();
        this.values.add(value);
    }

    public Tuple(Value[] values) {
        this.values = new ArrayList<Value>();
        this.values.addAll(Arrays.asList(values));
    }

    public Tuple(ArrayList<Value> values) {
        this.values = values;
    }

    public Tuple(Value[] values, Value primaryV) {
        this(values);
        this.primaryV = primaryV;
    }

    public ArrayList<Value> getValues() {
        return values;
    }

    public Value getPrimaryV() {
        return primaryV;
    }

    public Value getValue(int index) { return values.get(index);}

    public void setPrimaryV(Value primaryV) {
        this.primaryV = primaryV;
    }

    public void setValues(ArrayList<Value> values) {
        this.values = values;
    }

    public int getLength() {
        int sum = 0;
        for (Value value : values) {
            sum += value.getLength();
        }
        return sum;
    }

    /**
     * 联合索引比较的时候,先比较第一个索引值,若相等则再比较下一个索引值,依次类推
     */
    public int compare(Tuple tuple) {
        return primaryV.compare(tuple.getPrimaryV());
    }


    // Method to check if the Tuple satisfies the given condition
    public boolean checkCondition(ConditionNode conditionNode,Schema schema) {//对于每条tuple，传入条件筛选树和schema
        if (conditionNode instanceof Condition) {
            //叶节点
            Condition condition = (Condition) conditionNode;
            int columnIndex = getColumnIndex(condition.getColumn(),schema);//获取condition所约束的字段位置,需要对照schema
            return check(condition, columnIndex);//判断是否符合条件
        } else if (conditionNode instanceof ConditionOperator) {
            // 运算符节点，递归
            ConditionOperator operatorNode = (ConditionOperator) conditionNode;
            boolean leftResult = getLeftCheckResult(operatorNode.getLeft(),schema);
            boolean rightResult = getRightCheckResult(operatorNode.getRight(),schema);

            if (operatorNode.getOperator().equals("AND")) {
                return leftResult && rightResult;
            } else if (operatorNode.getOperator().equals("OR")) {
                return leftResult || rightResult;
            }
        }
        return false;
    }

    private boolean getLeftCheckResult(ConditionNode leftNode,Schema schema) {
        return checkCondition(leftNode,schema);
    }

    private boolean getRightCheckResult(ConditionNode rightNode,Schema schema) {
        return checkCondition(rightNode,schema);
    }

    // Helper method to get the index of the column (this assumes columns are ordered in the table schema)
    private int getColumnIndex(String columnName,Schema schema) {
        // Assuming the table's schema is available through a method `getSchema()` on the table object
        // You would fetch the index of the column based on its name

        return schema.getIndex(columnName);
    }
    public void showAll(){
        for(Value v:values){
            System.out.println(v);
        }
        System.out.println(primaryV);
    }

    /**
     * @param condition 比较条件
     * @param index 比较的下表
     * @return 是否符合条件
     */

    public boolean check(Condition condition, int index) {
        return switch (condition.getOperator()) {
            case "=" -> values.get(index).compare(condition.getValue()) == 0;
            case "!=" -> values.get(index).compare(condition.getValue()) != 0;
            case "<" -> values.get(index).compare(condition.getValue()) == -1;
            case ">" -> values.get(index).compare(condition.getValue()) == 1;
            case "<=" -> values.get(index).compare(condition.getValue()) <= 0;
            case ">=" -> values.get(index).compare(condition.getValue()) >= 0;
            default -> false;
        };
    }



    /**
     * 将tuple序列化，考量每个value的种类
     * @return tuple的序列化后的字节数组
     * @throws IOException
     */
    public byte[] toBytes() throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        DataOutputStream dataOut = new DataOutputStream(out);

        int primaryType = primaryV.getType();
        int primaryLen = primaryV.toBytes().length;
        byte[] primaryBytes = primaryV.toBytes();
        dataOut.writeInt(primaryType);
        dataOut.writeInt(primaryLen);
        dataOut.write(primaryBytes);

        for (Value value : values) {
            int type = value.getType();
            byte[] valueBytes = value.toBytes();
            int len = valueBytes.length;

            dataOut.writeInt(type);
            dataOut.writeInt(len);
            dataOut.write(valueBytes);
        }

        return out.toByteArray();
    }

    /**
     * 将字节数组读下来反序列化为tuple对象
     * @param data 字节数组
     * @return 反序列化得到的tuple对象
     */
    public static Tuple fromBytes(byte[] data) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(data));
        ArrayList<Value> values = new ArrayList<>();

        int primaryType = in.readInt();
        int primaryLen = in.readInt();

        byte[] primaryBytes = new byte[primaryLen];
        in.readFully(primaryBytes);
        Value priamryValue = decodeTypedValue(primaryType,primaryBytes);


        while(in.available() > 0) {
            int type = in.readInt();
            int len = in.readInt();

            if(type == 0){
                break;
            }

            byte[] valueBytes = new byte[len];
            in.readFully(valueBytes);
            Value value = decodeTypedValue(type,valueBytes);
            values.add(value);
        }
        return new Tuple(values.toArray(new Value[0]),priamryValue);
    }


    public static Value decodeTypedValue(int type, byte[] valueBytes) throws IOException {
        DataInputStream dataIn = new DataInputStream(new ByteArrayInputStream(valueBytes));
        switch (type) {
            case 5:
                return new NullValue();
            case 1:
                ByteArrayOutputStream stringBuffer = new ByteArrayOutputStream();
                int b;
                while ((b = dataIn.read()) != 0 && b != -1) {
                    stringBuffer.write(b);
                }
                return new StringValue(stringBuffer.toString(StandardCharsets.UTF_8));
            case 2:
                return new IntValue(dataIn.readInt());
            case 3:
                return new LongValue(dataIn.readLong());
            case 4:
                return new BooleanValue(dataIn.readBoolean());
            default:
                throw new IOException("未知类型: " + type);
        }
    }


}

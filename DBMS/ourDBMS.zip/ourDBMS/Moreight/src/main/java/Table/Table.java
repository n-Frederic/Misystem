package Table;

import Conditions.Condition;
import Database.DatabaseManager;
import Storage.BPlusTree.*;
import Storage.Page.*;
import Storage.Value.Value;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.*;
import java.util.regex.Pattern;

/**
 * Table类用于管理数据库表的操作。
 * 它支持插入数据、添加列、更新数据、删除数据等功能，表的结构定义和数据分别存储在JSON文件中。
 */
public class Table {
    private String tableName;
    private Schema schema;
    private BpTree tree;
    private PageManager pageManager;

    public Table(String tableName) throws IOException {
        this.tableName = tableName;
        this.pageManager = new PageManager(DatabaseManager.getBaseDir() + "/" + DatabaseManager.getCurrentDatabase() + "/" + tableName + "/" + tableName + ".idb");

        Meta meta = pageManager.getMeta();

        if (meta.getHighestPageId() == 0) this.tree = new BpTree();
        else this.tree = pageManager.buildTreeFromFile();

        this.schema = Schema.loadSchemaFromMeta(meta);
    }

    /**
     * 插入一行
     */
    public void insert(Tuple tuple) throws IOException {
        Meta meta = pageManager.getMeta();
        PageIO pageIO = pageManager.getPageIO();
        if (meta.getHighestPageId() == 0) {
            Page page = new Page(1, true, true);
            pageManager.insert(page, tuple, tree);

            tree.setRoot(page);
            tree.setHead(page);
            meta.setHighestPageId(1);                 // 程序内部meta更新值
            meta.setRootPageId(1);
            meta.setHeadPageId(1);

            meta.updateHighestPageId(pageIO.getFile());       // 将值更新到文件里
            meta.updateRootPageId(pageIO.getFile());
            meta.updateHeadPageId(pageIO.getFile());

            pageManager.updatePageToManager(page, true);              // 将第一页存到pages[1]，并放到待更新页集合里
            pageManager.flushModifiedPages();                   // 将待更新页全部写入文件

        } else {
            Page rootPage = pageManager.getPage(meta.getRootPageId());
            pageManager.insert(rootPage, tuple, tree);

        }

    }

    public void delete(ArrayList<Tuple> tuples) throws IOException {
        for(Tuple tuple : tuples) {
            delete(tuple);
        }
    }

    public void delete(Tuple tuple) throws IOException {
        Value primaryV = tuple.getPrimaryV();
        int pageId = pageManager.findPageNum(primaryV);
        Page dirPage = pageManager.getPage(pageId);
        pageManager.remove(dirPage, tuple, tree);
    }
    public boolean samePK(Value value){
        try{
            ArrayList<Tuple>tuples=selectAll();
            for(Tuple t:tuples){
                System.out.println("primaryV:"+t.getPrimaryV()+" "+value);
                if(t.getPrimaryV().toString().equals(value.toString())||(t.getPrimaryV().toString())==value.toString()){
                    System.out.println("false");
                    return false;
                }
            }
        }catch (IOException e){
            System.out.println("io exception");
        }
        System.out.println("true");
        return true;
    }




    /**
     * 可用，完全不涉及文件操作
     */
    // 最终返回只有fieldName的tuple的数组
    public ArrayList<Tuple> select(ArrayList<Tuple> tuples, ArrayList<String> fieldNames) {
        ArrayList<Tuple> result = new ArrayList<>();

        ArrayList<Integer> indexes = new ArrayList<>();
        for (String name : fieldNames) {
            indexes.add(schema.getIndex(name));
        }

        for (Tuple t : tuples) {
            Value[] selected = new Value[fieldNames.size()];
            for (int i = 0; i < indexes.size(); i++) {
                selected[i] = t.getValue(indexes.get(i));
            }
            result.add(new Tuple(selected));
        }

        return result;
    }

    public static boolean isReferencedByOtherTables() {
        //TODO:table是否被引用F
        return false;
    }

    /**
     * 可用
     */
    public ArrayList<Tuple> selectAll() throws IOException {
        ArrayList<Tuple> tuples = new ArrayList<>();

        if(tree.getHead() != null) {
            Page current = getPageManager().getPage(tree.getHead().getPageId());

            while (current != null) {
                tuples.addAll(current.getTuples());

                if (current.getNext() != null) {
                    current = getPageManager().getPage(current.getNext().getPageId());
                } else break;
            }
        } else System.out.println("Empty Set");

        return tuples;
    }


    public ArrayList<Tuple> where(Page page, Condition condition) throws IOException {
        ArrayList<Tuple> tuples = new ArrayList<>();
        Field field = schema.getField(condition.getColumn());
        int index = schema.getIndex(field);
        Value keyValue = condition.getValue();

        if(index == -1) {
            System.out.println("没有该列");
            return tuples;
        }


        if (field.isPrimaryKey()) {
            if (page.isLeaf()) {
                tuples.addAll(page.getTuples(condition, index));
                return tuples;
            } else {
                ArrayList<Value> entries = page.getEntries();
                switch (condition.getOperator()) {
                    case "=":
                        for (int i = 0; i < entries.size() - 1; i++) {
                            if (keyValue.compare(entries.get(i)) >= 0 && keyValue.compare(entries.get(i + 1)) < 0) {
                                Page temp1 = getPageManager().getPage(page.getChildren().get(i).getPageId());
                                tuples.addAll(where(temp1, condition));
                            }
                        }
                        Page temp1 = getPageManager().getPage(page.getChildren().get(page.getChildren().size()-1).getPageId());
                        tuples.addAll(where(temp1, condition));
                    case "!=":
                        tuples = selectAll();
                        Condition ec = new Condition(condition.getColumn(), condition.getValue(), "=");
                        tuples.removeAll(where(page, ec));
                    case "<":
                        for (int i = 0; i < entries.size(); i++) {
                            if (keyValue.compare(entries.get(i)) >= 0) {
                                Page temp2 = getPageManager().getPage(page.getChildren().get(i).getPageId());
                                tuples.addAll(where(temp2, condition));
                            }
                        }
                    case ">":
                        for (int i = 0; i < entries.size() - 1; i++) {
                            if (keyValue.compare(entries.get(i + 1)) < 0) {
                                Page temp3 = getPageManager().getPage(page.getChildren().get(i).getPageId());
                                tuples.addAll(where(temp3, condition));
                            }
                        }
                        Page temp3 = getPageManager().getPage(page.getChildren().get(page.getChildren().size()-1).getPageId());
                        tuples.addAll(where(temp3, condition));
                    case "<=":
                        Condition sc = new Condition(condition.getColumn(), condition.getValue(), "<");
                        tuples.addAll(where(page, sc));
                        Condition ec1 = new Condition(condition.getColumn(), condition.getValue(), "=");
                        tuples.addAll(where(page, ec1));
                    case ">=":
                        Condition bc = new Condition(condition.getColumn(), condition.getValue(), ">");
                        tuples.addAll(where(page, bc));
                        Condition ec2 = new Condition(condition.getColumn(), condition.getValue(), "=");
                        tuples.addAll(where(page, ec2));

                }
                return tuples;
            }
        } else {
            Page current = tree.getHead();

            while(current != null) {
                tuples.addAll(current.getTuples(condition,index));

                if(current.getNext() == null) {
                    break;
                } else {
                    current = getPageManager().getPage(current.getNext().getPageId());
                }
            }

            return tuples;
        }
    }

    public ArrayList<Tuple> whereLike(Condition condition) throws IOException {
        ArrayList<Tuple> tuples = new ArrayList<>();
        if(!condition.getOperator().equals("LIKE")) {
            System.out.println("不要用whereLike");
            return tuples;
        }

        Field field = schema.getField(condition.getColumn());
        int index = schema.getIndex(field);
        Value keyValue = condition.getValue();

        ArrayList<Tuple> temp = this.selectAll();
        for(Tuple tuple : temp) {
            if(sqlLike(condition.getValue().toString(),tuple.getValues().get(index).toString())){
                tuples.add(tuple);
            }
        }

        return tuples;
    }

    public ArrayList<Tuple> whereIn(ArrayList<Tuple> subTuples, Condition condition) throws IOException {
        ArrayList<Tuple> tuples = new ArrayList<>();
        if(!condition.getOperator().equals("IN")) {
            System.out.println("不要用whereIn");
            return tuples;
        }

        Field field = schema.getField(condition.getColumn());
        int index = schema.getIndex(field);

        ArrayList<Tuple> temp = this.selectAll();
        if(temp.get(0).getValues().size() != 1) {
            System.out.println("子查询里有不止一列，不能用IN");
            return tuples;
        }

        ArrayList<Value> values = new ArrayList<>();
        for(Tuple tuple : temp) {
            values.add(tuple.getValues().get(0));
        }

        for(Tuple tuple : subTuples) {
            if(values.contains(tuple.getValues().get(index))){
                tuples.add(tuple);
            }
        }

        return tuples;

    }

    public ArrayList<Tuple> where(ArrayList<Tuple> t1, ArrayList<Tuple> t2, String mode) {
        ArrayList<Tuple> tuples = new ArrayList<>();
        if (mode.equals("and")) {
            for (Tuple t : t1) {
                if (t2.contains(t)) {
                    tuples.add(t);
                }
            }
            return tuples;
        } else if (mode.equals("or")) {
            for (Tuple t : t1) {
                tuples.add(t);
            }
            for (Tuple t : t2) {
                if (!t1.contains(t)) {
                    tuples.add(t);
                }
            }
            return tuples;
        } else return tuples;
    }


    public PageManager getPageManager() {
        return pageManager;
    }

    public boolean hasForeignKeyConstraints() {
        return false;
        // TODO: 遍历schema检查是否有外键

    }

    public boolean containsValue(String keyName, Value keyValue) {
        return false;
        // TODO: 遍历主键值检查是否有外键
    }

    public boolean isColumnReferenced(String column) {
        return false;
        // TODO: 遍历column值检查是否有被引用外键


    }

    public boolean isColumnForeignKey(String column) {
        return false;
        // TODO: 遍历column值检查是否有引用其他外键

    }


    // 主键的情况遍历所有行，根页读出来，找到所在的页，从文件里读出来应该是用readPage()，
    // 找到一页getTuples()跟传进来的tuples做比较，一样的话把对应index的列的值改成新的值，
    // updatePageToManager然后再flushModifiedPages();
    // TODO: 等待黄爱雷提供单个tuple的完整筛查
    public void update(ArrayList<Tuple> tuples, Value newValue, String columnName) throws IOException {
        System.out.println("update被调了");
        System.out.println("待更新的 tuples 主键值：");
        for (Tuple tuple : tuples) {
            System.out.println(tuple.getPrimaryV());
        }

        if (schema.getPrimaryKeyName().equals(columnName)) {
            List<String> columnNames = schema.getColumnNames();
            int columnIndex = columnNames.indexOf(columnName);
            if (columnIndex == -1) {
                throw new IllegalArgumentException("列不存在: " + columnName);
            }


            // 主键更新
            for (Tuple tuple : tuples) {
                System.out.println("目标主键值：" + tuple.getPrimaryV());
                int pageId = pageManager.findPageNum(tuple.getPrimaryV());
                Page page = pageManager.getPage(pageId);
                ArrayList<Tuple> pageTuples = page.getTuples();

                for (Tuple t : pageTuples) {
                    System.out.println("遍历到tuple，主键：" + t.getPrimaryV());
                    if (t.getPrimaryV().toString().equals(t.getPrimaryV().toString())) {
                        System.out.println("匹配成功，准备更新！");
                        System.out.println("修改前: " + t.getValues().get(columnIndex));
                        t.getValues().set(columnIndex,newValue);
                        tuple.getValues().set(columnIndex,newValue);
                        System.out.println("修改后: " + t.getValues().get(columnIndex));
                        pageManager.updatePageToManager(page, true);
                        break;
                    }
                }
            }
            pageManager.flushModifiedPages();

        } else {
            // 非主键字段更新
            List<String> columnNames = schema.getColumnNames();
            int columnIndex = columnNames.indexOf(columnName);
            if (columnIndex == -1) {
                throw new IllegalArgumentException("列不存在: " + columnName);
            }
            Page head = tree.getHead();

            while (head != null) {
                Page page = pageManager.getPageIO().readPage(head.getPageId());
                ArrayList<Tuple> pageTuples = page.getTuples();

                for (Tuple t : pageTuples) {
                    System.out.println("遍历非主键更新，当前tuple主键：" + t.getPrimaryV());

                    for (Tuple target : tuples) {
                        if (t.getPrimaryV().toString().equals(target.getPrimaryV().toString())) {
                            System.out.println("匹配成功！开始更新 " + columnName + " -> " + newValue);
                            t.getValues().set(columnIndex,newValue);
                            target.getValues().set(columnIndex,newValue);
                            pageManager.updatePageToManager(page, true);
                            break;
                        }
                    }
                }
                head = head.getNext();
            }
            pageManager.flushModifiedPages();
        }
    }

// TODO: 等待一个能直接操作的
//    public void delete()

//    public void truncate() {
//        tree.truncate();
//    }

    public Schema getSchema() {
        return schema;
    }

    public BpTree getTree() {
        return tree;
    }

    public static boolean sqlLike(String input, String likePattern) {
        // 第一步：转义 Java 正则的特殊字符（除了 % 和 _）
        StringBuilder regex = new StringBuilder();
        for (int i = 0; i < likePattern.length(); i++) {
            char c = likePattern.charAt(i);
            switch (c) {
                case '%':
                    regex.append(".*");
                    break;
                case '_':
                    regex.append(".");
                    break;
                case '\\':
                    regex.append("\\\\");
                    break;
                case '.': case '*': case '+': case '?': case '|':
                case '{': case '}': case '[': case ']': case '(': case ')':
                case '^': case '$':
                    regex.append("\\").append(c);
                    break;
                default:
                    regex.append(c);
            }
        }

        Pattern pattern = Pattern.compile(regex.toString(), Pattern.DOTALL);
        return pattern.matcher(input).matches();
    }




















    /*    public static void addColumn(String tableName, Field newField) {
        Path schemaPath = From_schema(tableName);
        Path dataPath = From_data(tableName);

        JsonObject schema;
        try (FileReader reader = new FileReader(schemaPath.toFile())) {
            schema = JsonParser.parseReader(reader).getAsJsonObject();
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        JsonArray fields = schema.getAsJsonArray("fields");

        // 添加新字段结构
        JsonObject newFieldJson = new JsonObject();
        newFieldJson.addProperty("fieldName", newField.getName());

        JsonArray constraintsArray = new JsonArray();

        JsonObject typeObj = new JsonObject();
        typeObj.addProperty("Type", newField.getType());
        constraintsArray.add(typeObj);
        System.out.println(newFieldJson);
        System.out.println(typeObj);

        if (newField.isNotNull()) {
            JsonObject notNullObj = new JsonObject();
            notNullObj.addProperty("NOT NULL", true);
            constraintsArray.add(notNullObj);
        }

        if (newField.isUnique()) {
            JsonObject uniqueObj = new JsonObject();
            uniqueObj.addProperty("UNIQUE", true);
            constraintsArray.add(uniqueObj);
        }

        if (newField.isPrimaryKey()) {
            JsonObject pkObj = new JsonObject();
            pkObj.addProperty("PRIMARY KEY", true);
            constraintsArray.add(pkObj);
        }

        if (newField.getDefault() != null && !newField.getDefault().isEmpty()) {
            JsonObject defaultObj = new JsonObject();
            defaultObj.addProperty("Default", newField.getDefault());
            constraintsArray.add(defaultObj);
        }

        newFieldJson.add("constraint", constraintsArray);
        fields.add(newFieldJson);

        try (FileWriter writer = new FileWriter(schemaPath.toFile())) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(schema, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 更新所有旧数据记录，添加新字段默认值
        JsonArray data = readData(dataPath);
        for (JsonElement e : data) {
            JsonObject obj = e.getAsJsonObject();
            if (newField.getDefault() != null && !newField.getDefault().isEmpty()) {
                obj.addProperty(newField.getName(), newField.getDefault());
            } else {
                obj.add(newField.getName(), JsonNull.INSTANCE);
            }
        }

        try (FileWriter writer = new FileWriter(dataPath.toFile())) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(data, writer);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }*/

// set是针对于where筛选后的JsonArray修改列值
//    public static void Set(String tableName, HashMap<String,String> map, ConditionNode logicTree) {
////
//        JsonArray all = Table.From_data(tableName);
//
//// 逻辑过滤，返回的是 all 中的部分元素，但它们和 all 中是同一个 JsonObject 引用
//        JsonArray data = logicTree.evaluate();
//
//// 就地修改
//        for (JsonElement e : data) {
//            JsonObject obj = e.getAsJsonObject();
//            for (Map.Entry<String,String> entry : map.entrySet()) {
//                obj.addProperty(entry.getKey(), entry.getValue());
//            }
//        }
//
//// all 已经被改了，后面只要把 all 序列化/写文件就行
//
//    }


//    public static JsonArray Where(JsonArray a, JsonArray b, String mode) {
//        JsonArray array = new JsonArray();
//        if (mode.equals("and")) {
//            for (JsonElement e : a) {
//                if (b.contains(e)) {
//                    array.add(e);
//                }
//            }
//            return array;
//        } else if (mode.equals("or")) {
//            for (JsonElement e : a) {
//                array.add(e);
//            }
//            for (JsonElement e : b) {
//                if (!array.contains(e)) {
//                    array.add(e);
//                }
//            }
//            return array;
//        } else return array;
//    }

//    public static void Where(JsonArray data, Condition condition) {
//        Iterator<JsonElement> iterator = data.iterator();
//
//        while (iterator.hasNext()) {
//            JsonElement element = iterator.next();
//            JsonObject object = element.getAsJsonObject();
//
//            switch (condition.getOperator()) {
//                case "=":
//                    if (!object.get(condition.getColumn()).getAsString().equals(condition.getValue())) {
//                        iterator.remove(); // 使用 iterator.remove() 删除当前元素
//                    }
//                    break;
//                case "!=":
//                    if (object.get(condition.getColumn()).getAsString().equals(condition.getValue())) {
//                        iterator.remove(); // 使用 iterator.remove() 删除当前元素
//                    }
//                    break;
//                case "<":
//                    if (object.get(condition.getColumn()).getAsString().compareTo(condition.getValue()) >= 0) {
//                        iterator.remove(); // 使用 iterator.remove() 删除当前元素
//                    }
//                    break;
//                case ">":
//                    if (object.get(condition.getColumn()).getAsString().compareTo(condition.getValue()) <= 0) {
//                        iterator.remove(); // 使用 iterator.remove() 删除当前元素
//                    }
//                    break;
//                case "<=":
//                    if (object.get(condition.getColumn()).getAsString().compareTo(condition.getValue()) > 0) {
//                        iterator.remove(); // 使用 iterator.remove() 删除当前元素
//                    }
//                    break;
//                case ">=":
//                    if (object.get(condition.getColumn()).getAsString().compareTo(condition.getValue()) < 0) {
//                        iterator.remove(); // 使用 iterator.remove() 删除当前元素
//                    }
//                    break;
//            }
//        }
//
//    }


//    public static void deleteColumn(String tableName, String columnName) {
//        // 处理 schema
//        Path schemaPath = From_schema(tableName);
//        JsonObject schemaObj;
//        try (FileReader reader = new FileReader(schemaPath.toFile())) {
//            schemaObj = JsonParser.parseReader(reader).getAsJsonObject();
//        } catch (IOException e) {
//            e.printStackTrace();
//            return;
//        }
//
//        JsonArray fields = schemaObj.getAsJsonArray("fields");
//        JsonArray newFields = new JsonArray();
//
//        for (JsonElement elem : fields) {
//            JsonObject field = elem.getAsJsonObject();
//            if (!field.get("fieldName").getAsString().equals(columnName)) {
//                newFields.add(field);
//            }
//        }
//
//        schemaObj.add("fields", newFields);
//
//        try (FileWriter writer = new FileWriter(schemaPath.toFile())) {
//            Gson gson = new GsonBuilder().setPrettyPrinting().create();
//            gson.toJson(schemaObj, writer);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        // 处理 data
//        Path dataPath = From_data(tableName);
//        JsonArray data = readData(dataPath);
//
//        for (JsonElement element : data) {
//            JsonObject obj = element.getAsJsonObject();
//            obj.remove(columnName);
//        }
//
//        try (FileWriter writer = new FileWriter(dataPath.toFile())) {
//            Gson gson = new GsonBuilder().setPrettyPrinting().create();
//            gson.toJson(data, writer);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

// 更新内存并保存到磁盘


//    public static void saveData(String tableName, JsonArray data) {
//        Path dataPath = From_data(tableName);
//        try (FileWriter writer = new FileWriter(dataPath.toFile())) {
//            Gson gson = new GsonBuilder()
//                    .setPrettyPrinting()
//                    .serializeNulls()
//                    .create();
//            gson.toJson(data, writer);
//        } catch (IOException e) {
//            throw new RuntimeException("写入表 " + tableName + " 失败", e);
//        }
//    }


//    public static void Set(String tableName, HashMap<String,String> map, ConditionNode logicTree) {
//        // 1. 读出整表
//        JsonArray all = readData(From_data(tableName));
//
//        // 2. 逻辑过滤，返回的是 all 中的部分元素（原始引用）
//        JsonArray data = logicTree.evaluate(all);
//
//        // 3. 就地修改这些元素
//        for (JsonElement e : data) {
//            JsonObject obj = e.getAsJsonObject();
//            for (Map.Entry<String,String> entry : map.entrySet()) {
//                obj.addProperty(entry.getKey(), entry.getValue());
//            }
//        }
//
//        // 4. 最后将 all 整个写回文件
//        saveData(tableName, all);
//    }

//    public static void renameColumn(String tableName, String oldName, String newName) {
//        // 修改 schema
//        Path schemaPath = From_schema(tableName);
//        JsonObject schemaObj;
//        try (FileReader reader = new FileReader(schemaPath.toFile())) {
//            schemaObj = JsonParser.parseReader(reader).getAsJsonObject();
//        } catch (IOException e) {
//            e.printStackTrace();
//            return;
//        }
//
//        JsonArray fields = schemaObj.getAsJsonArray("fields");
//        for (JsonElement elem : fields) {
//            JsonObject field = elem.getAsJsonObject();
//            if (field.get("fieldName").getAsString().equals(oldName)) {
//                field.addProperty("fieldName", newName);
//                break;
//            }
//        }
//
//        try (FileWriter writer = new FileWriter(schemaPath.toFile())) {
//            Gson gson = new GsonBuilder().setPrettyPrinting().create();
//            gson.toJson(schemaObj, writer);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//
//        // 修改 data
//        Path dataPath = From_data(tableName);
//        JsonArray data = readData(dataPath);
//
//        for (JsonElement element : data) {
//            JsonObject obj = element.getAsJsonObject();
//            if (obj.has(oldName)) {
//                JsonElement value = obj.remove(oldName);
//                obj.add(newName, value);
//            }
//        }
//
//        try (FileWriter writer = new FileWriter(dataPath.toFile())) {
//            Gson gson = new GsonBuilder().setPrettyPrinting().create();
//            gson.toJson(data, writer);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }
//

//    public static void Delete(JsonArray oldData, JsonArray newData) {
//        Iterator<JsonElement> iterator = newData.iterator();
//
//        while (iterator.hasNext()) {
//            JsonElement element = iterator.next();
//            if(oldData.contains(element)) oldData.remove(element);
//        }
//    }

//    public static Path From_data(String table) {
//        Path dataPath = Paths.get(DIRECTORY, DatabaseManager.getCurrentDatabase(), table + "_data.json");
//        return dataPath;
//    }
//
//    public static Path From_schema(String table) {
//        Path schemaPath = Paths.get(DIRECTORY, DatabaseManager.getCurrentDatabase(), table + "_schema.json");
//        return schemaPath;
//    }

//    public static JsonArray readData(Path dataPath) {
//        JsonArray data;
//        try {
//            FileReader reader = new FileReader(dataPath.toFile());
//            data = JsonParser.parseReader(reader).getAsJsonArray();
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        }
//        return data;
//    }

//    public static JsonArray readSchema(Path schemaPath) {
//        JsonArray fields;
//        try {
//            FileReader reader = new FileReader(schemaPath.toFile());
//            fields = JsonParser.parseReader(reader).getAsJsonArray();
//        } catch (FileNotFoundException e) {
//            throw new RuntimeException(e);
//        }
//        return fields;
//    }
//        //传个al的tup，根据键找到位置，针对每个tp，内层是root调get()

}


